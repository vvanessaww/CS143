
SELECT COUNT(DISTINCT city, country)
FROM Affiliations
WHERE name = "University of California";